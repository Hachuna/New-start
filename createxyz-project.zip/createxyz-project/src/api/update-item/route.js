async function handler({
  id,
  name,
  price,
  unit,
  description,
  categoryId,
  photos,
  code,
}) {
  if (!id || !name || !price || !unit) {
    return { error: "ID, name, price and unit are required" };
  }

  // Check if code is provided and unique (excluding current item)
  if (code) {
    const [existingItem] = await sql`
      SELECT id FROM items WHERE code = ${code} AND id != ${id}
    `;
    if (existingItem) {
      return { error: "An item with this code already exists" };
    }
  }

  return await sql.transaction(async (txn) => {
    const [item] = await txn`
      UPDATE items 
      SET 
        name = ${name},
        price = ${price},
        unit = ${unit},
        description = ${description},
        category_id = ${categoryId},
        code = ${code},
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `;

    if (!item) {
      return { error: "Item not found" };
    }

    await txn`DELETE FROM item_photos WHERE item_id = ${id}`;

    if (photos && photos.length > 0) {
      await txn`
        INSERT INTO item_photos (item_id, photo_url, display_order)
        SELECT ${id}, url, row_number() OVER ()
        FROM unnest(${photos}::text[]) AS url
      `;
    }

    const [result] = await txn`
      SELECT 
        i.*,
        c.name as category_name,
        c.color as category_color,
        COALESCE(json_agg(ip.photo_url) FILTER (WHERE ip.photo_url IS NOT NULL), '[]') as photos
      FROM items i
      LEFT JOIN categories c ON i.category_id = c.id
      LEFT JOIN item_photos ip ON i.id = ip.item_id
      WHERE i.id = ${id}
      GROUP BY i.id, c.name, c.color
    `;

    return {
      item: {
        id: result.id,
        name: result.name,
        price: result.price,
        unit: result.unit,
        description: result.description,
        code: result.code,
        category: result.category_name
          ? {
              name: result.category_name,
              color: result.category_color,
            }
          : null,
        photos: result.photos,
        created_at: result.created_at,
        updated_at: result.updated_at,
      },
    };
  });
}
export async function POST(request) {
  return handler(await request.json());
}