async function handler({ name, color, parentId }) {
  if (!name || !color) {
    return { error: "Name and color are required" };
  }

  const [category] = await sql`
    INSERT INTO categories (name, color, parent_id)
    VALUES (${name}, ${color}, ${parentId || null})
    RETURNING id, name, color, parent_id
  `;

  return {
    category: {
      id: category.id,
      name: category.name,
      color: category.color,
      parentId: category.parent_id,
    },
  };
}
export async function POST(request) {
  return handler(await request.json());
}