async function handler({ search, categoryId }) {
  let queryText = `
    SELECT 
      i.*,
      c.name as category_name,
      c.color as category_color,
      COALESCE(json_agg(ip.photo_url) FILTER (WHERE ip.photo_url IS NOT NULL), '[]') as photos
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    LEFT JOIN item_photos ip ON i.id = ip.item_id
    WHERE 1=1
  `;

  const values = [];
  let paramCount = 1;

  if (search) {
    queryText += ` AND (LOWER(i.name) LIKE $${paramCount} OR LOWER(i.description) LIKE $${paramCount})`;
    values.push(`%${search.toLowerCase()}%`);
    paramCount++;
  }

  if (categoryId) {
    queryText += ` AND i.category_id = $${paramCount}`;
    values.push(categoryId);
    paramCount++;
  }

  queryText += ` GROUP BY i.id, c.name, c.color ORDER BY i.created_at DESC`;

  const items = await sql(queryText, values);

  return {
    items: items.map((item) => ({
      id: item.id,
      name: item.name,
      price: item.price,
      unit: item.unit,
      description: item.description,
      category: item.category_name
        ? {
            name: item.category_name,
            color: item.category_color,
          }
        : null,
      photos: item.photos,
      created_at: item.created_at,
      updated_at: item.updated_at,
    })),
  };
}
export async function POST(request) {
  return handler(await request.json());
}