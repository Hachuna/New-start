async function handler({ search, categoryId }) {
  let queryText = `
    SELECT 
      i.code,
      i.name,
      i.price,
      i.unit,
      i.description,
      c.name as category_name,
      i.created_at,
      i.updated_at
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    WHERE 1=1
  `;

  const values = [];
  let paramCount = 1;

  if (search) {
    queryText += ` AND (LOWER(i.name) LIKE $${paramCount} OR LOWER(i.description) LIKE $${paramCount})`;
    values.push(`%${search.toLowerCase()}%`);
    paramCount++;
  }

  if (categoryId) {
    queryText += ` AND i.category_id = $${paramCount}`;
    values.push(categoryId);
    paramCount++;
  }

  queryText += ` ORDER BY i.created_at DESC`;

  const items = await sql(queryText, values);

  const csvHeader =
    "Code,Name,Price,Unit,Description,Category,Created At,Updated At\n";
  const csvRows = items
    .map((item) => {
      return [
        item.code || "",
        item.name,
        item.price,
        item.unit,
        item.description || "",
        item.category_name || "",
        new Date(item.created_at).toISOString(),
        new Date(item.updated_at).toISOString(),
      ]
        .map((field) => `"${String(field).replace(/"/g, '""')}"`)
        .join(",");
    })
    .join("\n");

  const csvContent = csvHeader + csvRows;

  return {
    csv: csvContent,
    filename: `items-export-${new Date().toISOString().split("T")[0]}.csv`,
  };
}
export async function POST(request) {
  return handler(await request.json());
}