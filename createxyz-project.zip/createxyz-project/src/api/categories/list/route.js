async function handler() {
  const categories = await sql`
    WITH RECURSIVE category_tree AS (
      SELECT 
        id,
        name,
        color,
        parent_id,
        0 as level,
        ARRAY[id] as path
      FROM categories 
      WHERE parent_id IS NULL
      
      UNION ALL
      
      SELECT 
        c.id,
        c.name,
        c.color,
        c.parent_id,
        ct.level + 1,
        ct.path || c.id
      FROM categories c
      JOIN category_tree ct ON c.parent_id = ct.id
    )
    SELECT 
      id,
      name,
      color,
      parent_id,
      level,
      path
    FROM category_tree
    ORDER BY path
  `;

  return {
    categories: categories.map((category) => ({
      id: category.id,
      name: category.name,
      color: category.color,
      parentId: category.parent_id,
      level: category.level,
    })),
  };
}
export async function POST(request) {
  return handler(await request.json());
}