async function handler({ id }) {
  if (!id) {
    return { error: "Item ID is required" };
  }

  const [deletedItem] = await sql`
    DELETE FROM items 
    WHERE id = ${id}
    RETURNING id
  `;

  if (!deletedItem) {
    return { error: "Item not found" };
  }

  return { success: true };
}
export async function POST(request) {
  return handler(await request.json());
}