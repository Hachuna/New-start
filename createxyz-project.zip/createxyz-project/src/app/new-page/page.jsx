"use client";
import React from "react";

function MainComponent() {
  // ... previous state variables ...
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [newCategory, setNewCategory] = useState({
    name: "",
    color: "#000000",
    parentId: "",
  });

  // ... previous functions ...

  const handleCategorySubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/categories/create", {
        method: "POST",
        body: JSON.stringify(newCategory),
      });

      if (!response.ok) throw new Error("Failed to create category");

      await fetchCategories();
      setShowCategoryModal(false);
      setNewCategory({
        name: "",
        color: "#000000",
        parentId: "",
      });
    } catch (err) {
      console.error(err);
      setError("Failed to create category");
    }
  };

  return (
    <div
      className={`min-h-screen ${
        darkMode ? "bg-gray-900 text-white" : "bg-white text-gray-800"
      }`}
    >
      // previous header
      {/* Search and Filters */}
      <div className="p-4 flex gap-4 flex-wrap">
        <input
          type="text"
          placeholder="Search items..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="p-2 border rounded flex-grow"
        />
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Add New Item
        </button>
        <button
          onClick={() => setShowCategoryModal(true)}
          className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
        >
          Manage Categories
        </button>
      </div>
      // previous error message and items grid // previous add/edit modal
      {/* Category Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-lg ${
              darkMode ? "bg-gray-800" : "bg-white"
            } p-6`}
          >
            <h2 className="text-xl font-bold mb-4">Add New Category</h2>
            <form onSubmit={handleCategorySubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block mb-1">Name</label>
                  <input
                    type="text"
                    value={newCategory.name}
                    onChange={(e) =>
                      setNewCategory((prev) => ({
                        ...prev,
                        name: e.target.value,
                      }))
                    }
                    className="w-full p-2 border rounded"
                    required
                  />
                </div>
                <div>
                  <label className="block mb-1">Color</label>
                  <input
                    type="color"
                    value={newCategory.color}
                    onChange={(e) =>
                      setNewCategory((prev) => ({
                        ...prev,
                        color: e.target.value,
                      }))
                    }
                    className="w-full p-2 border rounded h-10"
                    required
                  />
                </div>
                <div>
                  <label className="block mb-1">
                    Parent Category (Optional)
                  </label>
                  <select
                    value={newCategory.parentId}
                    onChange={(e) =>
                      setNewCategory((prev) => ({
                        ...prev,
                        parentId: e.target.value,
                      }))
                    }
                    className="w-full p-2 border rounded"
                  >
                    <option value="">None</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {"  ".repeat(category.level)}
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowCategoryModal(false);
                    setNewCategory({
                      name: "",
                      color: "#000000",
                      parentId: "",
                    });
                  }}
                  className="px-4 py-2 border rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
                >
                  Add Category
                </button>
              </div>
            </form>

            {/* Category List */}
            <div className="mt-6">
              <h3 className="font-bold mb-2">Existing Categories</h3>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {categories.map((category) => (
                  <div
                    key={category.id}
                    className="flex items-center gap-2 p-2 rounded"
                    style={{ marginLeft: `${category.level * 1.5}rem` }}
                  >
                    <div
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: category.color }}
                    ></div>
                    <span>{category.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;